Generic tests for clients with Publisher/Subscriber model

# Requirements

Java 17+

# Download

[Release versions](pubsubtests/release/CHANGELOG.md)

Or you can add dependency to it as follows:

Gradle:

```
dependencies {
  implementation 'io.github.lambdaprime:pubsubtests:1.0'
}
```

# Documentation

[Documentation](http://portal2.atwebpages.com/pubsubtests)

[Development](DEVELOPMENT.md)

# Contacts

lambdaprime <intid@protonmail.com>
